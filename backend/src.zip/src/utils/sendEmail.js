const nodemailer = require("nodemailer");

const mailSender = async (email, title, body) => {
  const mailUser = (process.env.Mail_User || process.env.MAIL_USER || "").trim();
  const mailPass = (process.env.Mail_Pass || process.env.MAIL_PASS || "").trim();
  const mailHost = (process.env.Mail_Host || process.env.MAIL_HOST || "smtp.gmail.com").trim();

  if (!mailUser || !mailPass) {
    throw new Error("Mail_User or Mail_Pass not configured in .env");
  }

  const transporter = nodemailer.createTransport({
    host: mailHost,
    port: 587,
    secure: false,
    auth: {
      user: mailUser,
      pass: mailPass,
    },
  });

  const info = await transporter.sendMail({
    from: `"Magic Mistry" <${mailUser}>`,
    to: email,
    subject: title,
    html: body,
  });
;
  return info;
};

module.exports = mailSender;